#!/bin/sh
# Generate configure.in from configure.ac
# Generate Makefile from Makefile.am 
printenv

# Files not included in autoconf --add-missing
[ -f "NEWS" ] || touch "NEWS"
[ -f "README" ] || touch "README"
[ -f "AUTHORS" ] || touch "AUTHORS"
[ -f "ChangeLog" ] || touch "ChangeLog"

[ -z "$AUTORECONF_OPTS" ] && AUTORECONF_OPTS="-i -s"

autoreconf $AUTORECONF_OPTS $* || exit 1
automake --add-missing || exit 1
./configure --host=${BUILD_CC} || exit 1
echo "*** done"

